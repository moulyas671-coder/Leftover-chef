
const express = require("express");
const csv = require("csv-parser");
const cors= require("cors");
const fs = require("fs");
const path = require("path");
const dotenv = require("dotenv");

dotenv.config();

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

// Location of your Indian recipe CSV file
const csvFile = path.join(__dirname, "IndianFoodDataset.csv");

let allRecipes = [];

// Load the CSV dataset
function loadRecipes() {
    return new Promise((resolve, reject) => {
        const recipes = [];

        if (!fs.existsSync(csvFile)) {
            return reject(
                new Error("IndianFoodDataset.csv was not found.")
            );
        }

        fs.createReadStream(csvFile)
            .pipe(csv({
                mapHeaders: ({ header }) =>
                    header.replace(/^\uFEFF/, "").trim()
            }))
            .on("data", (row) => {
                recipes.push(row);
            })
            .on("end", () => {
                allRecipes = recipes;
                console.log(`Loaded ${allRecipes.length} recipes.`);
                resolve();
            })
            .on("error", reject);
    });
}

// Test the server
app.get("/", (req, res) => {
    res.send("Leftover Chef recipe server is running!");
});

// Search recipes by ingredient
app.get("/api/recipes", (req, res) => {
    const ingredient = String(req.query.ingredient || "")
        .trim()
        .toLowerCase();

    if (!ingredient) {
        return res.status(400).json({
            message: "Please enter an ingredient."
        });
    }

    if (ingredient.length > 60) {
        return res.status(400).json({
            message: "Ingredient name is too long."
        });
    }

    const results = allRecipes
        .filter((row) => {
            const ingredients = (
                (row.TranslatedIngredients || "") +
                " " +
                (row.Ingredients || "")
            ).toLowerCase();

            return ingredients.includes(ingredient);
        })
        .slice(0, 10)
        .map((row) => ({
            name:
                row.TranslatedRecipeName ||
                row.RecipeName ||
                "Unnamed recipe",

            ingredients:
                row.TranslatedIngredients ||
                row.Ingredients ||
                "Not available",

            instructions:
                row.TranslatedInstructions ||
                row.Instructions ||
                "Not available",

            preparationTime: row.PrepTimeInMins || "",
            cookingTime: row.CookTimeInMins || "",
            totalTime: row.TotalTimeInMins || "",
            servings: row.Servings || "",
            cuisine: row.Cuisine || "",
            course: row.Course || "",
            diet: row.Diet || "",
            source: row.URL || ""
        }));

    res.json({
        searchedIngredient: ingredient,
        totalResults: results.length,
        recipes: results
    });
});

// Search for a recipe photo using Unsplash

// Search for a recipe photo using Unsplash
app.get("/api/recipe-image", async (req, res) => {
    const recipeName = String(req.query.name || "").trim();

    if (!recipeName) {
        return res.status(400).json({
            message: "Recipe name is required."
        });
    }

    const accessKey = process.env.UNSPLASH_ACCESS_KEY;

    if (!accessKey) {
        return res.status(503).json({
            message: "Unsplash key has not been configured."
        });
    }

    // Try different search terms
    const searchTerms = [
        recipeName + " Indian food",
        recipeName + " Indian dish",
        recipeName + " food photography",
        recipeName + " recipe"
    ];

    try {
        let photo = null;

        for (const search of searchTerms) {
            const response = await fetch(
                "https://api.unsplash.com/search/photos?query=" +
                encodeURIComponent(search) +
                "&per_page=5&orientation=landscape",
                {
                    headers: {
                        Authorization: `Client-ID ${accessKey}`,
                        "Accept-Version": "v1"
                    }
                }
            );

            if (!response.ok) {
                throw new Error(
                    "Unsplash API error: " + response.status
                );
            }

            const data = await response.json();

            if (data.results && data.results.length > 0) {
                photo = data.results[0];
                break;
            }
        }

        if (!photo) {
            return res.json({
                recipeName,
                photo: null,
                message: "No matching photograph found."
            });
        }

        res.json({
            recipeName,
            photo: {
                imageUrl: photo.urls.regular,
                photographer: photo.user.name,
                photographerUrl:
                    photo.user.links.html +
                    "?utm_source=leftover_chef&utm_medium=referral",
                unsplashUrl:
                    "https://unsplash.com/?utm_source=leftover_chef&utm_medium=referral"
            }
        });

    } catch (error) {
        console.error("Photo search error:", error.message);

        res.status(500).json({
            message: "Unable to search for the recipe photo."
        });
    }
});

// Load the dataset before starting the server
loadRecipes()
    .then(() => {
        app.listen(PORT, () => {
            console.log(
                `Leftover Chef server running at http://localhost:${PORT}`
            );
        });
    })
    .catch((error) => {
        console.error("Dataset loading failed:", error.message);
    });
