
const express = require("express");
const csv = require("csv-parser");
const cors = require("cors");
const fs = require("fs");
const path = require("path");
const dotenv = require("dotenv");

dotenv.config({ path: path.join(__dirname, ".env") });

const app = express();
const PORT = 5000;

// Allow communication with the dashboard
app.use(cors());
app.use(express.json());

// CSV dataset location
const csvFile = path.join(__dirname, "..", "indian-receipe-api", "IndianFoodDataset.csv");

let allRecipes = [];

// ======================================
// LOAD INDIAN RECIPE DATASET
// ======================================

function loadRecipes() {
    return new Promise((resolve, reject) => {

        const recipes = [];

        if (!fs.existsSync(csvFile)) {
            return reject(
                new Error(
                    "IndianFoodDataset.csv was not found. " +
                    "Keep it in the same folder as server.js."
                )
            );
        }

        fs.createReadStream(csvFile)
            .pipe(csv({
                mapHeaders: ({ header }) =>
                    header.replace(/^\uFEFF/, "").trim()
            }))
            .on("data", (row) => {
                recipes.push(row);
            })
            .on("end", () => {

                allRecipes = recipes;

                console.log(
                    `Successfully loaded ${allRecipes.length} recipes.`
                );

                resolve();
            })
            .on("error", reject);
    });
}

// ======================================
// TEST BACKEND
// ======================================

app.get("/", (req, res) => {

    res.send("Leftover Chef recipe server is running!");

});

// ======================================
// SEARCH TOP 3 MATCHING RECIPES
// ======================================

app.get("/api/recipes", (req, res) => {

    const ingredient = String(req.query.ingredient || "")
        .trim()
        .toLowerCase();

    if (!ingredient) {
        return res.status(400).json({
            message: "Please enter an ingredient."
        });
    }

    if (ingredient.length > 60) {
        return res.status(400).json({
            message: "Ingredient name is too long."
        });
    }

    // Find recipes containing the entered ingredient
    const matchingRecipes = allRecipes.filter((row) => {

        const ingredients = (
            (row.TranslatedIngredients || "") +
            " " +
            (row.Ingredients || "")
        ).toLowerCase();

        return ingredients.includes(ingredient);
    });

    // Select a maximum of three matching recipes
    const results = matchingRecipes
        .slice(0, 3)
        .map((row) => ({

            name:
                row.TranslatedRecipeName ||
                row.RecipeName ||
                "Unnamed recipe",

            ingredients:
                row.TranslatedIngredients ||
                row.Ingredients ||
                "Not available",

            instructions:
                row.TranslatedInstructions ||
                row.Instructions ||
                "Not available",

            preparationTime: row.PrepTimeInMins || "",
            cookingTime: row.CookTimeInMins || "",
            totalTime: row.TotalTimeInMins || "",
            servings: row.Servings || "",
            cuisine: row.Cuisine || "",
            course: row.Course || "",
            diet: row.Diet || "",
            source: row.URL || ""

        }));

    res.json({

        searchedIngredient: ingredient,
        totalResults: results.length,
        recipes: results

    });

});

// ======================================
// SEARCH RECIPE PHOTO USING UNSPLASH
// ======================================

app.get("/api/recipe-image", async (req, res) => {

    const recipeName = String(req.query.name || "").trim();

    if (!recipeName) {
        return res.status(400).json({
            message: "Recipe name is required."
        });
    }

    const accessKey = process.env.UNSPLASH_ACCESS_KEY;

    if (!accessKey) {
        return res.status(503).json({
            message: "Unsplash key has not been configured. Check your .env file."
        });
    }

    const searchTerms = [
        recipeName + " Indian food",
        recipeName + " Indian dish",
        recipeName + " food photography",
        recipeName + " recipe"
    ];

    try {

        let photo = null;

        for (const search of searchTerms) {

            const response = await fetch(
                "https://api.unsplash.com/search/photos?query=" +
                encodeURIComponent(search) +
                "&per_page=5&orientation=landscape",
                {
                    headers: {
                        Authorization: `Client-ID ${accessKey}`,
                        "Accept-Version": "v1"
                    }
                }
            );

            if (!response.ok) {
                throw new Error(
                    "Unsplash API error: " + response.status
                );
            }

            const data = await response.json();

            if (data.results && data.results.length > 0) {
                photo = data.results[0];
                break;
            }
        }

        if (!photo) {
            return res.json({
                recipeName,
                photo: null,
                message: "No matching photograph found."
            });
        }

        res.json({

            recipeName,

            photo: {
                imageUrl: photo.urls.regular,

                photographer: photo.user.name,

                photographerUrl:
                    photo.user.links.html +
                    "?utm_source=leftover_chef&utm_medium=referral",

                unsplashUrl:
                    "https://unsplash.com/?utm_source=leftover_chef&utm_medium=referral"
            }

        });

    } catch (error) {

        console.error(
            "Photo search error:",
            error.message
        );

        res.status(500).json({
            message: "Unable to search for the recipe photo."
        });

    }

});


// ==========================================
// GET FOOD IMAGE FOR INVENTORY ITEMS
// ==========================================

app.get("/api/food-image", async (req, res) => {
    try {
        const foodName = String(req.query.name || "").trim();

        if (!foodName) {
            return res.status(400).json({
                error: "Food name is required"
            });
        }

        const accessKey = process.env.UNSPLASH_ACCESS_KEY;

        if (!accessKey) {
            return res.status(500).json({
                error: "Unsplash API key is missing"
            });
        }

        // Search terms for common food itemssS
        const specialSearches = {
            milk: "fresh milk bottle",
            paneer: "fresh paneer cubes",
            butter: "butter in a dish",
            rice: "uncooked rice grains",
            spinach: "fresh spinach leaves",
            potato: "fresh potatoes",
            carrot: "fresh carrots",
            tomato: "fresh tomatoes",
            onion: "fresh onions",
            apple: "fresh apples",
            banana: "fresh bananas",
            mango: "fresh mango",
            cheese: "cheese block",
            curd: "plain curd in bowl",
            yogurt: "plain yogurt in bowl"
        };

        const searchTerm =
            specialSearches[foodName.toLowerCase()] ||
            `fresh ${foodName}`;

        const url = new URL(
            "https://api.unsplash.com/search/photos"
        );

        url.searchParams.set("query", searchTerm);
        url.searchParams.set("per_page", "1");
        url.searchParams.set("client_id", accessKey);

        const response = await fetch(url);

        if (!response.ok) {
            throw new Error(
                "Unsplash request failed: " + response.status
            );
        }

        const data = await response.json();

        if (!data.results || data.results.length === 0) {
            return res.json({
                photo: null
            });
        }

        const photo = data.results[0];

        return res.json({
            photo: {
                imageUrl: photo.urls.small,
                photographer: photo.user.name,
                unsplashUrl: photo.links.html
            }
        });

    } catch (error) {
        console.error("Food image error:", error.message);

        return res.status(500).json({
            error: "Unable to load food image"
        });
    }
});



// ======================================
// START SERVER AFTER LOADING DATASET
// ======================================

loadRecipes()

    .then(() => {

        app.listen(PORT, () => {

            console.log(
                `Leftover Chef server running at http://localhost:${PORT}`
            );

        });

    })

    .catch((error) => {

        console.error(
            "Dataset loading failed:",
            error.message
        );

    });
